function validareEmail() {
            var email = document.getElementById("email").value;
            if (email.includes('@')) {
                alert('Adresa de e-mail este validă!');
            } else {
                alert('Introduceți o adresă de e-mail validă!');
      }
  }
 let slideIndex = 0;
let slideshowInterval;

function showSlides() {
    let i;
    const slides = document.getElementsByClassName("mySlides");

    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    slideIndex++;

    if (slideIndex > slides.length) {
        slideIndex = 1;
    }

    slides[slideIndex - 1].style.display = "block";
}

function startSlideshow() {
    if (slideshowInterval) {
        clearInterval(slideshowInterval);
    }

    slideIndex = 0;
    showSlides();
    slideshowInterval = setInterval(showSlides, 3000); // Schimbă imaginea la fiecare 3 secunde
}